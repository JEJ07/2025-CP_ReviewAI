export const CONFIG = {
  // API_BASE_URL: "http://localhost:8000" // LOCAL DEVELOPMENT LNG TO REPLACE LATER WITH REAL URL
  // API_BASE_URL: "https://wawuri07.pythonanywhere.com" // PRODUCTION URL
  API_BASE_URL: "https://www.reviewai.live" // PRODUCTION URL
};
