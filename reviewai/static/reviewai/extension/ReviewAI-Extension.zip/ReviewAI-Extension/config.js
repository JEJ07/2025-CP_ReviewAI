export const CONFIG = {
  API_BASE_URL: "https://wawuri07.pythonanywhere.com" // LOCAL DEVELOPMENT LNG TO REPLACE LATER WITH REAL URL
};